package rima.pageobjects.homepage;

import org.openqa.selenium.WebDriver;
import rima.framework.core.BasePage;

public class GoogleHomepage extends BasePage {

    public GoogleHomepage(WebDriver driver) {
        super(driver);
    }
}
